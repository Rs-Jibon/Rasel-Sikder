<?php 

	function theme_files(){

		// style enqueue
		// wp_enqueue_style < function


		// script enqueue
		// wp_enqueue_script < function

	}
	add_action('init', 'theme-files');