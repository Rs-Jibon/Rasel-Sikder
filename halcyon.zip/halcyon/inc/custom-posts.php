<?php 

	function theme_custom_posts(){

		register_post_type('post_type', array(
			// information about post type
		));

	}

	add_action('init', 'theme_custom_posts');


	function theme_custom_taxonomy(){

		register_taxonomy('taxonomy', 'post_type', array(
			// information about category or tag << taxonomy
		));

	}

	add_action('init', 'theme_custom_taxonomy');