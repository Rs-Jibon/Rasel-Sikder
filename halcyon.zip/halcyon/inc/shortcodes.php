<?php 

function my_shortcode_func(){
	return 'Returning HTML';
}

add_shortcode('my_tag', 'my_shortcode_func');



function my_shortcode_func_with_attr($atts){

	extract(shortcode_atts(array(
		'attr_name' => 'attr default value'
	), $atts));

	return 'Returning HTML ' . $attr_name;
}

add_shortcode('my_tag_attr', 'my_shortcode_func_with_attr');


// double tag supported shortcode
function my_shortcode_func_with_attr_content($atts, $content = null){

	extract(shortcode_atts(array(
		'attr_name' => 'attr default value'
	), $atts));

	return 'Returning HTML ' . $attr_name . ' - ' . do_shortcode($content);
}

add_shortcode('my_tag_content', 'my_shortcode_func_with_attr_content');