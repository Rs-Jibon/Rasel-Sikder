<?php 

	function theme_sidebar(){

		register_sidebar(array(
			// information about sidebar
		));

	}
	add_action('init', 'theme_sidebar');