<?php 

	require 'inc/theme-files.php';
	require 'inc/sidebars.php';
	require 'inc/custom-posts.php';
	require 'inc/shortcodes.php';

	// for menu support 

	function theme_nav_menu(){
		register_nav_menus(array(
			'menu_id' => 'menu display name in dashboard'
		));
	}

	add_action('init', 'theme_nav_menu');

	// you can use option tree as a option framework to beautify your theme option panel & meta boxes
	